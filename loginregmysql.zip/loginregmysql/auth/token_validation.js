const jsonwebtoken = require("jsonwebtoken");
const expressJwt = require("express-jwt");
require("dotenv").config();
// exports.checkToken = (req, res, next) => {
//   const token = req.header("auth-token");
//   console.log(token);
//   if (!token) return res.status(401).send("Access denied");

//   try {
//     const verified = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = verified;
//     next();
//   } catch (err) {
//     res.status(400).send("Invalid token");
//   }
// };
// exports.checkToken = expressJwt({
//   secret: process.env.JWT_SECRET,
//   userProperty: "checkToken",
// });

// starts here

module.exports = {
  checkToken: (req, res, next) => {
    let token = req.get("authorizarion");

    // console.log(process.env.JWT_SECRET);
    // if (token) {
    //   token = token.slice(7);
    //   verify(token, process.env.JWT_SECRET, (err, decoded) => {
    //     console.log(decoded);
    //     if (err) {
    //       res.json({
    //         success: 0,
    //         message: "Invalid token",
    //       });
    //     } else {
    //       next();
    //     }
    //   });
    // } else {
    //   res.json({
    //     success: 0,
    //     message: "Access denied! unauthorized user",
    //   });
    // }
    var loginToken =
      req.headers.authentication || req.body.userToken || req.headers.Bearer; //or your own, it's just headers that pass from browser to client
    jsonwebtoken.verify(
      loginToken,
      new Buffer(process.env.JWT_SECRET, "base64"),
      function (err, decoded) {
        if (err) {
          return res.status(401).send({ message: "invalid_token" });
        }
        //be aware of encoded data structure, simply console.log(decoded); to see what it contains
        res.send(decoded); //`decoded.foo` has your value
      }
    );
  },
};
