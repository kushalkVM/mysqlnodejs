require("dotenv").config();
const express = require("express");
var bodyParser = require("body-parser");
const app = express();

// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

app.use(express.json());

app.get("/api", (req, res) => {
  res.json({
    success: 1,
    message: "This is rest API",
  });
});
const userRouter = require("./users/user.router");

app.use("/", userRouter);
const PORT = 8000;
app.listen(PORT, () => {
  console.log("Server is running on", PORT);
});
