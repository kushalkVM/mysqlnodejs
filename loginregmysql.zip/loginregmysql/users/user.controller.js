const {
  create,
  deleteUser,
  updateUser,
  userId,
  getUsers,
  email,
} = require("./user.service");
//const { genSaltSync, hashSync, compareSync } = require("bcrypt");
const bcrypt = require("bcryptjs");
require("dotenv").config();
const { sign } = require("jsonwebtoken");
// module.exports = {
//   createUser: (req, res)
exports.createUser = async (req, res, next) => {
  const password = req.body.password;
  const saltRounds = 10;
  bcrypt.genSalt(saltRounds, async function (err, salt) {
    if (err) {
      throw err;
    } else {
      await bcrypt.hash(password, salt, function (err, hash) {
        if (err) {
          throw err;
        } else {
          console.log(hash);
          var hash = hash;
          //$2a$10$FEBywZh8u9M0Cec/0mWep.1kXrwKeiWDba6tdKvDfEBjyePJnDT7K
          const body = req.body;
          body.password = hash;
          console.log(body);

          create(body, (err, results) => {
            if (err) {
              console.log(err);
              return res.ststus(500).json({
                success: 0,
                message: "database connection error",
              });
            }
            return res.status(200).json({
              success: 1,
              data: results,
            });
          });
        }
      });
    }
  });
};

exports.getUserbyid = async (req, res, next) => {
  console.log("inside getuserId");
  var id = req.params.id;
  console.log(id);

  userId(req.params.id, (err, results) => {
    if (err) {
      console.log(err);
      return;
    }
    console.log("results", results);
    if (results.length == 0) {
      return res.json({
        sucess: 0,
        message: "Record not found",
      });
    } else {
      return res.json({
        success: 1,
        data: results,
      });
    }
  });
};

exports.getusers = async (req, res, next) => {
  getUsers((err, results) => {
    if (err) {
      console.log(err);
      return;
    }
    if (!results) {
      return res.json({
        sucess: 0,
        message: "Record not found",
      });
    }
    return res.json({
      success: 1,
      data: results,
    });
  });
};

exports.updateuser = (req, res) => {
  const password = req.body.password;
  const saltRounds = 10;
  const id = req.params.id;
  bcrypt.genSalt(saltRounds, async function (err, salt) {
    if (err) {
      throw err;
    } else {
      await bcrypt.hash(password, salt, function (err, hash) {
        if (err) {
          throw err;
        } else {
          console.log(hash);
          var hash = hash;
          //$2a$10$FEBywZh8u9M0Cec/0mWep.1kXrwKeiWDba6tdKvDfEBjyePJnDT7K
          const body = req.body;
          body.password = hash;
          console.log(body);

          updateUser(id, body, (err, results) => {
            if (err) {
              console.log(err);
              return res.ststus(500).json({
                success: 0,
                message: "database connection error",
              });
            }
            return res.status(200).json({
              success: 1,
              data: results,
            });
          });
        }
      });
    }
  });
};

exports.deleteUser = (req, res) => {
  console.log(req.params.id);

  deleteUser(req.params.id, (err, results) => {
    if (err) {
      console.log(err);
      return err;
    }
    console.log(results);
    if (results === 0) {
      return res.json({
        success: 0,
        message: "Record not found",
      });
    }
    return res.json({
      success: 1,
      message: "user deleted successfully",
    });
  });
};

exports.login = async (req, res) => {
  const body = req.body;
  const saltRounds = 10;
  const hashPassword = await bcrypt.hash(body.password, saltRounds);
  // console.log("login", body);
  email(body.email, async (err, results) => {
    if (err) {
      console.log(err);
    }
    console.log(results[0]);
    if (!results[0]) {
      return res.json({
        success: 0,
        data: "Your entered email is not exist !!!",
      });
    }
    console.log("password", results[0].password);
    console.log("hashPassword", hashPassword);
    const result = await bcrypt.compare(body.password, results[0].password);
    // console.log(result);
    if (result) {
      // result.password = undefined;
      const jsontoken = sign({ result: results[0] }, process.env.JWT_SECRET, {
        expiresIn: "1h",
      });
      return res.json({
        success: 1,
        message: "login successfull",
        data: results[0],
        token: jsontoken,
      });
    } else {
      return res.json({
        success: 0,
        message: "password did not match !!",
        // data: results[0],
        // token: jsontoken,
      });
    }

    // const passwordEnteredByUser = "mypass123";
    password = req.body.password;
    // console.log("hash", this.hash);
    // const hash1 = hash;
    console.log(password);

    // bcrypt.compare(password, results[0].password, function (err, isMatch) {
    //   if (err) {
    //     throw err;
    //   } else if (!isMatch) {
    //     console.log("Password doesn't match!");
    //   } else {
    //     console.log("Password matches!");
    //   }
    // });
  });
};
