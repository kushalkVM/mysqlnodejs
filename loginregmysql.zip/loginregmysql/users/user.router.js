const {
  createUser,
  getUserbyid,
  // getUserbyid,
  getusers,
  updateuser,
  deleteUser,
  login,
} = require("./user.controller");
const { checkToken } = require("../auth/token_validation");
const express = require("express");
const router = express.Router();
router.post("/register", createUser);
router.get("/users", checkToken, getusers);
router.get("/user/:id", checkToken, getUserbyid);
router.patch("/updateuser/:id", checkToken, updateuser);
router.delete("/deleteuser/:id", checkToken, deleteUser);
router.post("/login", login);

module.exports = router;
