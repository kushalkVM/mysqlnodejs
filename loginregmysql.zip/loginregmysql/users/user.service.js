const pool = require("../config/database");

// module.exports = {
//   create: (data, callBack) => {
exports.create = (data, callBack) => {
  console.log(data);
  pool.query(
    `insert into regestration(firstname,lastname,gender,email,password,number)  values(?,?,?,?,?,?)`,
    [
      data.firstname,
      data.lastname,
      data.gender,
      data.email,
      data.password,
      data.number,
    ],
    (error, results, fields) => {
      if (error) {
        return callBack(error);
      }
      return callBack(null, results);
    }
  );
};

exports.getUsers = (callBack) => {
  pool.query(
    //`select id,firstname,lastname,gender,email,number from regestration`,
    `select * from regestration `,
    [],
    (error, results, fields) => {
      if (error) {
        callBack(error);
      }
      return callBack(null, results);
    }
  );
};

exports.userId = (id, callBack) => {
  pool.query(
    `select id,firstname,lastname,gender,email,number from regestration where id =?`,
    // `select * from regestration where id =?`,
    [id],
    (error, results, fields) => {
      if (error) {
        callBack(error);
      }
      return callBack(null, results);
    }
  );
};

exports.updateUser = (id, data, callBack) => {
  pool.query(
    `update regestration set firstname=?,lastname=?,gender=?,email=?,password=?,number=? where id=?`,
    [
      data.firstname,
      data.lastname,
      data.gender,
      data.email,
      data.password,
      data.number,
      id,
    ],
    (error, results, fields) => {
      if (error) {
        callBack(error);
      }
      return callBack(null, results[0]);
    }
  );
};

exports.deleteUser = (id, callBack) => {
  console.log("deleteUser", id);
  pool.query(
    `delete from regestration where id =?`,
    id,
    (error, results, fields) => {
      if (error) {
        callBack(error);
      }
      return callBack(null, results[0]);
    }
  );
};

exports.email = async (email, callBack) => {
  console.log(email);
  // `select * regestration where email =?`,
  // `select  from regestration where email =?`,
  // [email],
  // pool.query(
  //   "select * regestration where email='rama@gmail.com'",
  //   (error, results, fields) => {
  //     if (error) {
  //       callBack(error);
  //     }
  //     //return callBack(null, results);
  //     console.log(results);
  //   }
  // );
  pool.query(
    `select * from regestration where email =?`,
    // `select * from regestration where id =?`,
    [email],
    (error, results, fields) => {
      if (error) {
        callBack(error);
      }
      return callBack(null, results);
    }
  );
};
