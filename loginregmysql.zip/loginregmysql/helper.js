const bcrypt = require("bcryptjs");

const password = "mypass123";
const saltRounds = 10;

bcrypt.genSalt(saltRounds, function (err, salt) {
  if (err) {
    throw err;
  } else {
    bcrypt.hash(password, salt, function (err, hash) {
      if (err) {
        throw err;
      } else {
        console.log(hash);
        var hash = hash;
        //$2a$10$FEBywZh8u9M0Cec/0mWep.1kXrwKeiWDba6tdKvDfEBjyePJnDT7K
        const passwordEnteredByUser = "mypass125";
        console.log("hash", hash);
        const hash1 = hash;

        bcrypt.compare(passwordEnteredByUser, hash1, function (err, isMatch) {
          if (err) {
            throw err;
          } else if (!isMatch) {
            console.log("Password doesn't match!");
          } else {
            console.log("Password matches!");
          }
        });
      }
    });
  }
});

// const passwordEnteredByUser = "mypass123";
// console.log("hash", this.hash);
// const hash1 = hash;

// bcrypt.compare(passwordEnteredByUser, hash1, function (err, isMatch) {
//   if (err) {
//     throw err;
//   } else if (!isMatch) {
//     console.log("Password doesn't match!");
//   } else {
//     console.log("Password matches!");
//   }
// });
